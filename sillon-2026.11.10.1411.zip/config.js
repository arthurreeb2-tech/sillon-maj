/* Identifiants publics des services (PKCE : aucun secret ici). Vides = mode démo.
   Spotify : developer.spotify.com → ton app → Redirect URI « sillon://callback ».
   Google : console Google Cloud → identifiant OAuth de type iOS, bundle fr.reebe.sillon, API YouTube Data v3 activée.
   Apple Music : rien ici — active le service MusicKit sur l'App ID fr.reebe.sillon.
   Logos : dépose les fichiers officiels dans www/logos/ (voir LISEZMOI.txt) puis indique leur chemin ; vide = initiales. */
window.SILLON_CONFIG = {
  spotify: { clientId: '8d7ab811a2904dc385fdd208041b86f1', redirectWeb: 'http://127.0.0.1:8888/index.html' },   // redirectWeb : test sur le Mac (python3 -m http.server 8888 --bind 127.0.0.1 dans www/)
  google: { clientIdIos: '' },
  // mises à jour à chaud : adresse GitHub Pages et clé publique Ed25519 (la clé privée reste sur le Mac : ~/.sillon/cle-maj.pem)
  maj: { url: 'https://arthurreeb2-tech.github.io/sillon-maj/', clePublique: 'F3+/pZRwZPjCSwLE7pQ9LB/uFSTIOfl6+i9rbEfQC7E=' },
  logos: { spotify: 'logos/spotify-icone.png', apple: 'logos/apple-icone.png', youtube: 'logos/youtube-icone.png' }
};
